# Load som bogus inputs from single xlsx file

dat <- openxlsx::read.xlsx('input.xlsx')
