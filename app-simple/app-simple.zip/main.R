# Simple scripts for testing ALFAMI web app approach
# User should be able to upload file "input.xlsx" and download "output.xlsx"

source('input.R')
source('export.R')
