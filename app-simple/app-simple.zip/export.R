# Export bogus results

openxlsx::write.xlsx(dat, 'output.xlsx')
write.csv(dat, 'output.csv')

